# Worked example — Zillow Offers (calibration only)

USE: to calibrate your own judgement of what a good answer looks like, and to show a student ONLY when they
explicitly ask for an example or have finished their own appraisal. Never show it before or during their
answers: it anchors groups on the same verdict. If a student wants to appraise Zillow itself, decline politely
and ask them to pick a tool they know first-hand — the case is already solved on the course platform.

Full version: https://tflsixsigma-png.github.io/lean-six-sigma-digital-tools-benchmarking/worked-examples.html#two

## The case in five facts
Zillow Offers (2018–2021) bought homes at prices set by a machine-learning valuation model, renovated and resold
them. In 2021, under "Project Ketchup", offers were adjusted upward; Zillow bought about 74% of the homes it made
offers on (target 50–60%) and about 15,000 homes in nine months, against 4,162 in all of 2020. Renovation and
resale did not scale. On 2 November 2021 Zillow wound the business down: about $304M inventory write-down in Q3,
a Homes-segment pre-tax loss of $422M, $240–265M further losses expected in Q4, a 25% workforce cut. CEO: "the
unpredictability in forecasting home prices far exceeds what we anticipated."

## The appraisal, condensed (as of mid-2021)
- **1** Pricing and acquisition. In production more than a year. AI: Yes.
- **2a** A and P — not C: nothing the organisation could do afterwards without the system.
  *Split:* groups claim C for "a decade of data and talent"; apply the switch-off test.
- **2c** No WIP limit — purchases outran renovation capacity. Little's Law did not stop at the screen.
- **2d** The one place — the estimate replaced human judgement, so the failure was systematic.
- **2e** Fully adopted (74% of offers bought). Adoption was the mechanism, not the problem.
- **2f** Months — Opendoor and Offerpad ran comparable models.
- **3.0** No, only modelling (back-tests). **3.1** Drifted — a listing estimate pushed into a months-ahead resale
  forecast in a regime change. *Split:* "the Zestimate was accurate" — accurate at what, for which decision?
- **3.2** Yes — straight into the offer. *Surprising reading:* integration succeeded, and that removed the human
  check.
- **3.3** No — could not renovate and resell at the rate it bought.
- **3.4** Partly — growth was steered, unit margin was not.
- **3.5** No — only the gain counted. **3.6** No comparison group.
- **4.1** Formally accuracy; in practice volume (win 50–60% of offers). **4.2** Not documented — no rule for when
  accuracy and volume conflicted. *This is the field that makes the case.*
- **4.3** No stated confidence reached the decision. **4.4** A change in the today-vs-three-months price
  relationship — exactly what 2021 did.
- **4.5** Cared about profit per home; given estimated resale value; missing renovation cost and capacity,
  holding time, rival iBuyers. **4.6** Only when something went wrong.
- **5a** Philosophical · Capability · Technical. *Split:* groups put Technical first because the CEO blamed
  forecasting; the error was survivable at 4,000 homes a year and fatal at 15,000 with raised offers.
- **5b** Pause. **5c** Stop raising offers until the objective hierarchy is written and unit margin is the steered
  indicator. (The company chose "Do not proceed".)

Sources: Zillow Group Form 8-K and Q3 2021 shareholder letter (2 Nov 2021); press reporting (Business Insider via
Inman, 2021).
