# The appraisal report — the platform's text format (sections 1–5)

The course platform's Digital Tool Appraisal page has a **"Paste from the AI coach"** box. It reads the exact
text format below (the same format its own "Copy as text" button produces), fills every field, recomputes the
readout, and lets the student click **"Download as PDF"** — the same typeset PDF report every other student
submits. So the report you hand over must follow this format **exactly**: same title lines, section titles in
capitals, two-space indent, `Label: value`, same labels and order. Do not add, rename or reorder lines.
Sections 6–7 are not part of this report (they are the separate Benchmarking Study).

## Rules
- Each field is one line: two spaces, the label, a colon, a space, the value. **Keep every value on one line** —
  no line breaks inside an answer (the platform reads line by line).
- For a multiple-choice field, the value is the full option text, exactly as written in `instrument.md`.
  Exception — the three debt lines take the bare name only: `Technical`, `Philosophical`, `Adoption`,
  `Capability` (or `None that we can see` for the largest debt).
- For a free-text field, the value is the student's own words, lightly tidied (spelling). Never improve the
  substance. If the student's answer is that nobody knows, keep their sentence (or write `unknown` if that is all
  they said) — it is their answer, not an empty field.
- An empty or unanswered field, or a closed field with no fitting option, is written `—` (em dash).
- The TELEOLOGY, EPISTEMOLOGY and ONTOLOGY blocks appear **only** if "Contains AI or ML" is "Yes" or "Unsure —
  the vendor says so; we cannot say what it does". Otherwise omit those three titles and their lines entirely.
- Labels, titles and option texts are in English even if the conversation was in another language; the student's
  free-text answers stay in the language they wrote them.
- Put the whole report inside one fenced code block (```text … ```) so it can be copied in one click without
  formatting. If you can create files, also save it as `tool-appraisal-<slug>.txt` (slug: tool name in lower case,
  every run of characters other than a–z and 0–9 replaced by a hyphen, no leading or trailing hyphens, at most 40
  characters).

## Template

```text
DIGITAL TOOL APPRAISAL
Digital Tools & Benchmarking — what one tool actually changes, and what it leaves undone
Module 3, Session 4 · 17 October 2026 · Sorbonne Business School / IDGP Academy

Appraised by: <role or name the student gave, or —>

THE TOOL
  Tool or platform: <1a>
  Workflow automated: <1b>
  Stage: <1c>
  Contains AI or ML: <1d>

VCAP TRIAGE
  Which term it moves: <2a>
  The C claim, defended: <2b>
  WIP limiting: <2c>
  Single source, or one more copy: <2d>
  Adoption, expected vs actual: <2e>
  Time to replication: <2f>

THE SIX CONDITIONS
  0 · Evidence base: <3.0>
  1 · Technical capability in operation: <3.1>
  2 · Workflow integration: <3.2>
  Recipient, step and actual use: <3.2b>
  3 · Translation into action: <3.3>
  The action, owner and dependencies: <3.3b>
  4 · Organisational outcome: <3.4>
  5 · Net value: <3.5>
  Weakest point in the evidence: <3.6>

TELEOLOGY
  What it optimises for: <4.1>
  Hierarchy of objectives documented: <4.2>

EPISTEMOLOGY
  Uncertainty and escalation: <4.3>
  What would invalidate the training data: <4.4>

ONTOLOGY
  What you care about, the stand-in it was given, and what the stand-in misses: <4.5>
  Review of the representation: <4.6>

THE VERDICT
  Largest debt: <5a first>
  Second debt: <5a second, or —>
  Third debt: <5a third, or —>
  Decision: <5b>
  First step and owner: <5c>

WHAT THESE ANSWERS SAY
  • <readout sentence>
  • <readout sentence>

Digital Tool Appraisal · Sorbonne Business School / IDGP Academy · Prof. Dr. Thiago Lima
```

The platform recomputes "What these answers say" itself when the text is pasted, so a slip there does not reach
the PDF — but write it correctly anyway, because the student reads it in the conversation.

## "What these answers say" — the platform's rules

Build this section mechanically, from the answers alone. Include a sentence only when its condition holds, in
exactly this order, with exactly this wording (replace only the parts in angle brackets), each as a line
starting with two spaces and `• `. If no sentence applies, omit the whole section, title included.

A **flagged** condition answer means one of these options:
- 3.0: "No, only modelling or vendor material" or "Not measured, or nobody has looked"
- 3.1: "No, or performance has drifted" or "Not measured"
- 3.2: "No — it is available rather than delivered" or "Not measured — we do not know if it is used"
- 3.3: "No — identification without capacity to act" or "Not measured — we do not know the follow-through rate"
- 3.4: "No — benefit stated in general terms" or "Measured only by what users report"
- 3.5: "No — only the gain has been counted" or "Not measured"

"Partly" and "Yes" answers are never flagged. A **not measured** answer is one whose option text begins with
"Not measured" — including 3.0 "Not measured, or nobody has looked" (3.4 has no such option). A not-measured
answer is also flagged, so it can be the first break.

Condition names, by number: 0 evidence base · 1 technical capability in operation · 2 workflow integration ·
3 translation into action · 4 organisational outcome · 5 net value.

1. **Term** (exactly one of these, by 2a):
   - A, P and C with 2b empty → `You claimed this moves C and left the defence blank. That is the one combination worth revisiting before the appraisal goes anywhere: name what the organisation will be able to do afterwards without the system, or drop the claim to A and P.`
   - A, P and C with 2b filled → `You claimed C and defended it. Hold that sentence — it is what the business case should be arguing, and it is usually the part that goes unwritten.`
   - A → `You placed this in A. That is a correctly identified purchase, not a weakness — but it means any competitor with the same budget can hold the same position, and the business case should be argued on that basis rather than on advantage.`
   - A and P → the same sentence with `A and P` in place of `A`.
   - Honestly, none of them yet → `You could not place it in any term. Worth resolving before money moves.`
2. 2c is "No — it only makes starting work easier" → `It makes work easier to start and does not cap what is in progress. By Little’s Law that lengthens lead time rather than shortening it — expect more in flight, not faster delivery.`
3. 2d is "One more copy …" → `It adds another home for the same fact. That is a standing reconciliation cost, and it is the mechanism by which dashboards become negotiations.`
4. 2f is "Months — they would buy the same product" → `A competitor buys the same thing in months. Whatever advantage this produces has to come from something other than the tool.`
5. Only if 1d is Yes or Unsure:
   - a. Pillars flagged — teleology if 4.2 is "Not documented …" or "Nobody in this organisation could answer it"; epistemology if 4.3 is "It returns an answer with no stated confidence" or "We do not know"; ontology if 4.6 is "Nobody — it has the representation it was built with". If at least one → `Unarticulated pillars: <list, comma-separated, in that order>. Not a judgement on the system — a statement that the assumption was never written down, and therefore cannot be audited or improved. This is debt in C arriving dressed as a purchase of A.`
   - b. 1d is Unsure → `You cannot say what the AI in this tool does. Before anything else, that is the question to put to the vendor in writing.`
   - c. 4.4 empty → `You have not named what would invalidate its training data. Every model learns the conditions that produced its data; naming the event that ends those conditions is the cheapest safeguard available.`
   - d. 4.5 empty → `You have not named a variable the system cannot see. Either the representation is unusually complete, or nobody has looked — and the second is far more common.`
6. **First break** = the lowest-numbered flagged condition among 3.0–3.5.
   - If it is 0, 1, 4 or 5 → `The chain first stops being a clear yes at condition <n> · <name>. Conditions after it cannot compensate, so this is the one to resolve before anything downstream is argued.`
   - If it is 2 or 3 → `The chain first stops being a clear yes at condition <n> · <name> — one of the two organisational conditions. This is not a fault in the tool and no vendor can fix it: it is the capability the tool was supposed to be buying. It is also where the reviewed evidence says value is most often lost.`
7. Any not-measured answers → `Not measured at: <n · name; n · name; …>. An unobserved implementation is a more tractable problem than a failing one — the next step is to measure, not to spend.`
8. All six conditions answered, none flagged, none not measured → `No break and no missing measure across all six conditions. That is rare; it is worth checking the answers against evidence somebody outside the project would accept.`
9. 3.6 is anything other than "None — …" (and not empty) → `Your evidence fails at least one of the three conditions on evidence quality. That does not make the tool wrong — it makes every answer above provisional, and it should be said in the business case rather than discovered later.`
10. 3.3b empty and at least one of 3.0–3.5 answered → `You have not written the action sentence: when the output says X, who does what, using what. Until that sentence exists, the project has identified a capability rather than a benefit.`
11. If at least one sentence above was included, end with → `Next: the Benchmarking Study — one reference that already does this well, and the six-month roadmap across the three capability gaps.`

Note that "Partly" answers produce no sentence: the platform treats the first *flagged* condition as the break.
The coach's own observation of the first condition that is not a clear yes (which may be a "Partly") belongs in
the conversation, not in this section.
