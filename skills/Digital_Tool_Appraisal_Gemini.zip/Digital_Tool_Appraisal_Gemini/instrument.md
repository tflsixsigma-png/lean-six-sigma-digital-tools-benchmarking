# The Digital Tool Appraisal — sections 1 to 5

Source: *Digital Tool Appraisal*, Prof. Dr. Thiago Lima, IAE Paris – Sorbonne Business School · IDGP Academy,
Module 3, Session 4 (17 October 2026). The wording of every field and option below is the instrument's own.
Use it exactly; do not add options, merge options or invent new fields.

Sections 6 (Benchmarking) and 7 (Capability gaps and the six-month roadmap) are NOT part of this appraisal.
They are the separate Benchmarking Study on the course platform.

---

## What the fields depend on (the three ideas)

### 1. A tool enters the bracket; it does not touch the coefficient — V = C × (A + P)
Assets (A) and processes (P) are additive and purchasable; capability (C) is a coefficient.
A platform is almost always an **A** decision — the organisation owns something new. Sometimes it is also a
**P** decision — the way work flows changes. It is very rarely a **C** decision, which would mean the
organisation ends up better at improving its processes than it was before. The error that destroys business
cases is paying for A and booking the benefit as though C had moved.

### 2. Six conditions between a working tool and a result
| # | Condition | Belongs to |
|---|---|---|
| 0 | Evidence base | THE TOOL |
| 1 | Technical capability in operation | THE TOOL |
| 2 | Workflow integration | CAPABILITY 1 (the organisation) |
| 3 | Translation into action | CAPABILITY 2 (the organisation) |
| 4 | Organisational outcome | THE RESULT |
| 5 | Net value | THE RESULT |

Each is necessary and none is sufficient: a break at any link stops the effect, however good the links before
it. Conditions 2 and 3 are not properties of the tool at all — they are capabilities of the organisation that
bought it, and they are where a systematic review of real implementations found value most often lost.
The chain is drawn from that review (Lima, manuscript in preparation); its evidence base is hospital
implementations and it is used as a structure for appraisal, not as a citable result.

### 3. Where the tool contains AI: three things nobody wrote down
| Pillar | The question | What it looks like when it is missing |
|---|---|---|
| Teleology | What has the system been told to want — and when its objectives conflict, which one wins? | It optimises one metric brilliantly and nobody can say what it traded away |
| Epistemology | What is it allowed to count as knowing — and does it know when it does not know? | It returns an answer with high confidence in conditions that no longer resemble its training data |
| Ontology | What is it able to see — and which variable that matters does not exist for it? | A supplier represented by price and lead time alone, in a decision that turned on geopolitics |

The three questions are Schrage and Kiron's (*Philosophy Eats AI*, MIT Sloan Management Review, 2025).
"Philosophical debt" — what accumulates when they go unasked — is from *Excelência Operacional* (Lima, 2026),
Chapter 5. An assumption nobody wrote down is one nobody can audit or improve — which is why section 4 asks
not whether the system is good, but whether the assumption was articulated.

---

## General rule for answering
Appraise one tool at a time. Answer from what the organisation can actually evidence, not from what the
business case promised. "Not documented" and "nobody knows" are the most useful answers — they are precisely
what the instrument is looking for. There is no score.

---

## 1 · The tool

**1a. Tool or platform** — What it is called.

**1b. The workflow it automates** — Be specific. "Improves collaboration" is not a workflow. One line.

**1c. Where it stands**
- Under evaluation — not yet bought
- Bought, being implemented
- In production under a year
- In production more than a year

**1d. Does it include AI or machine learning?**
Anything that learns from data, scores, ranks, forecasts, classifies or generates. If a vendor calls it AI and
you are not sure what it does, answer yes — that uncertainty is itself a finding.
- Yes
- Unsure — the vendor says so; we cannot say what it does
- No

---

## 2 · VCAP triage — what does it actually change?

**2a. Which term does it move?**
Training people to operate the new system is part of delivering the asset. C means the organisation ends up
better at improving its processes than it was before.
- A — we own something we did not own before
- A and P — the way work flows changes too
- A, P and C — we will also be better at improving afterwards
- Honestly, none of them yet

**2b. If you claimed C: what will the organisation be able to do afterwards that it cannot do now — and that
does not depend on this system?**
Leave blank if you did not claim C. A blank here is a legitimate and common answer.

**2c. Does it limit work in progress?**
Work in progress is everything started and not yet finished. With the same capacity, more in flight means each
item waits longer — Little's Law from the morning. A tool that makes work easier to start without capping what
is in progress lengthens lead time by construction.
- Yes — there is an explicit cap, and it is enforced
- There is a cap that nobody enforces
- No — it only makes starting work easier

**2d. Does it become the one place this information is kept — or one more copy?**
Take the main thing the tool records: a schedule date, a risk, a cost, a customer. Afterwards, is there a single
place to look for it, with every other system reading from there? If the same information also keeps living in a
spreadsheet or in the old system, somebody reconciles the copies forever, and the dashboards become
negotiations.
- The one place — it replaces the current sources, and the others are switched off
- One more copy — the same information keeps living elsewhere too
- Neither — it reads from an existing system and keeps no copy of its own

**2e. Adoption — expected against actual**
Of the people meant to do their work inside it — not just log in — what share actually do? Write "too early" if
it is not live. A tool used by 40% of its intended users does not deliver 40% of a single-source benefit; it
delivers close to none, because the other 60% still has to be reconciled. (e.g. expected 100%, actual about 40%)

**2f. How long before a competitor with the same budget has the same thing?**
This is the test for whether the tool buys advantage or only parity. Anything purchasable is available to a rival
at roughly the same price.
- Months — they would buy the same product
- A year or two
- Longer, because of what we would also have to build

---

## 3 · Capability maturity — the six conditions
The chain from a working tool to an organisational result, after Lima (manuscript in preparation). It applies to
any tool; where the tool contains AI, conditions 0 and 1 bite harder. Each condition is necessary and none is
sufficient, so the useful answer is the first one that is not a clear yes. Not measured is a legitimate and common
answer — and a more tractable finding than a failure.

Read across, the six answers are a maturity statement, and a more defensible one than a stage number: they say
which conditions this organisation can currently satisfy and demonstrate, which it satisfies without evidence,
and which it has never observed. There is no composite score here on purpose. A single figure would hide the
only thing worth knowing, which is where the chain stops.

**3.0 Evidence base — has this kind of application produced a measured result in a real organisation?**
"Kind of application" means the job: demand forecasting, scheduling, document generation, risk scoring, case
prioritisation. Not a model, not a simulation, not a pilot that reported accuracy — an implementation somebody
measured afterwards, ideally in an organisation like yours.
- Yes, in a comparable organisation
- Partly — results exist but diverge
- No, only modelling or vendor material
- Not measured, or nobody has looked

**3.1 Technical capability in operation — does it do here what the demo did, on our data, the way we actually
run it?**
For any tool: has anyone checked, after go-live, that it performs as specified on our volumes and our
exceptions? For an AI tool, more sharply: vendor accuracy was measured on the vendor's data with the vendor's
settings — has it been checked on ours, with the cut-off we actually use, counting only outputs that tell people
something they did not already know?
- Yes, verified locally after deployment
- Partly — verified once, not monitored
- No, or performance has drifted
- Not measured

**3.2 Workflow integration — does the output reach whoever decides, while the decision is still open?**
The first of the two organisational conditions. Name the person and the step, not the dashboard.
- Yes — named recipient, inside the decision window
- Partly — it arrives, but late or to the wrong role
- No — it is available rather than delivered
- Not measured — we do not know if it is used

**3.2b Who receives the output, at which step, and is it in fact used?**
Two thirds of staff rarely or never opening the tool is the commonest observed failure, and it is invisible
unless somebody asks. (Role · step in the process · evidence of use)

**3.3 Translation into action — is there an owner able to act, with the resources the action requires?**
The second organisational condition. If acting on the output needs three approvals, a budget line and a resource
nobody has, an earlier warning changes nothing — the constraint was never information.
- Yes — named owner, resourced, low barrier
- Partly — owner named, resources contested
- No — identification without capacity to act
- Not measured — we do not know the follow-through rate

**3.3b The action, its owner, and what it depends on**
Write the sentence the business case should contain: when the output says X, who does what, using what.

**3.4 Organisational outcome — which indicator should move, measured how?**
One named indicator, one data source, one baseline — and not a satisfaction survey. Where perception and
objective measurement were collected together, they diverged.
- Yes — named indicator, source and baseline
- Partly — indicator named, no baseline
- No — benefit stated in general terms
- Measured only by what users report

**3.5 Net value — what does the gain cost, and who bears it?**
Who is de-prioritised, which work moves to other people or other hours, and what checking the output takes.
The hour saved in the back office that reappears as an hour of overtime in the front office is not a gain; it is a
relocation.
- Yes — the displaced cost is identified and accepted
- Partly — suspected but not quantified
- No — only the gain has been counted
- Not measured

**3.6 How good is the evidence you just used to answer?**
Three things make a result trustworthy: a comparison group measured at the same time, an objective measure
rather than what people said they felt, and a source that is not selling the tool. Tick the weakest point in what
you relied on. Vendor material usually fails at least two of the three.
- None — a comparison group at the same time, an objective measure, an independent source
- No comparison group — only before-and-after, so anything else that changed gets credited to the tool
- Measured by what users reported, not by an objective figure
- The figures come from the vendor
- More than one of these

---

## 4 · Philosophical debt audit — AI only
Applies only if 1d is "Yes" or "Unsure". If 1d is "No", go straight to section 5.
Three pillars, after Schrage and Kiron. The question in each case is not whether the system is good, but
whether the organisation has articulated the assumption.

### Teleology — what it is told to want
The hierarchy of purposes. Most critical, most often skipped.

**4.1 What is it optimising for, precisely?**
The number the system actually tries to maximise or minimise — cost per order, forecast error, time to
resolution — not the business goal it was sold against. If nobody can say, write "unknown". That is the finding,
not a gap in your answer.

**4.2 Is the hierarchy of objectives documented?**
When cost, service level, risk and sustainability conflict, is it written down which wins?
- Yes — written, owned and reviewed
- Written once, never revisited
- Not documented — it is implicit in the configuration
- Nobody in this organisation could answer it

### Epistemology — what it is allowed to count as knowing
How it acquires knowledge, validates it, and expresses certainty.

**4.3 Does it express uncertainty, and does anything happen when it is high?**
- Yes — low confidence escalates to a human, automatically
- It reports confidence; nothing is triggered by it
- It returns an answer with no stated confidence
- We do not know

**4.4 What would invalidate its training data?**
A model learns the conditions that generated its data. Name the event that would end those conditions — a
market shift, a regulation, a reorganisation, a pandemic.

### Ontology — what it is able to see
Which entities it recognises, which relations it models, which variables do not exist for it.

**4.5 What has the system been given as a stand-in for the thing you actually care about — and what does the
stand-in leave out?**
Schrage and Kiron's example: a company wants loyal customers and hands the system recency, frequency, spend
and NPS. Those are proxies, not loyalty, and the system optimises the proxies. Write the thing you care about,
the measure the system was given instead, and one thing that matters to the decision which that measure cannot
see — a relationship, a regulatory change, a supplier's own fragility. The map is not the territory.

**4.6 Who reviews what the system represents, and when?**
- A named owner, on a fixed cadence
- Only when something goes wrong
- Nobody — it has the representation it was built with

---

## 5 · The verdict

**5a. Rank the debts, largest first**
More than one is usually present. Put the one that would do most damage if left alone at the top; leave the lower
ranks blank if only one or two apply.
- **Technical** — a shortcut in the artefact itself.
- **Philosophical** — purpose, knowledge or representation that nobody wrote down.
- **Adoption** — a tool that works and is not used.
- **Capability** — a tool the organisation could not improve after buying it.
- None that we can see

**5b. The decision**
- Proceed
- Proceed once named conditions are met — write the first of them as the step below
- Pause — the debt has to be paid first
- Do not proceed

**5c. The first step, and who owns it** — One line.

---

## Reading the result (Part THREE of the instrument)
The instrument has no score, deliberately. It produces three things worth looking at.

1. **Which term you could defend.** Most honest appraisals land on A, or on A and P. That is a correctly
   identified purchase, not a failure. The failure is claiming C and being unable to say, in one sentence, what
   the organisation will be able to do afterwards without the system.
2. **Where the chain first stops being a clear yes.** That link is the finding. If it is condition 2 or 3, the
   problem is the organisation's and no vendor can fix it. If the answer is "not measured", the next step is to
   measure, not to spend — an unobserved implementation is a far more tractable problem than a failing one.
3. **Where the tool contains AI, how many pillars nobody wrote down.** Not how good the system is — whether the
   assumption was articulated. Teleology is cheap to write down before deployment and expensive afterwards, once
   the system has been acting on the implicit hierarchy for two years.

---

## Sources
- Schrage, M., & Kiron, D. (2025). Philosophy eats AI. *MIT Sloan Management Review*. The three pillars and the
  argument that the binding constraint on value from AI is philosophical rather than technical are theirs.
- Schrage, M., & Kiron, D. (2024). Is philosophy the next LLM training frontier? MIT Initiative on the Digital
  Economy.
- Lima, T. F. (2026). *Excelência operacional: da estratégia à execução*, ch. 1 (V = C × (A + P)) and ch. 5
  (the three pillars for operations). Atena Editora. Open access.
- Van Mieghem, J. A., & Allon, G. (2015). *Operations Strategy: Principles and Practice* (2nd ed.). Dynamic Ideas.

The mapping between the three pillars and the operational arguments of the session — teleology to order
winners, epistemology to signalling at the source, ontology to causal ambiguity — is this course's, not the
original authors'.
