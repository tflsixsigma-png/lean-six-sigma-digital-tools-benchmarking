# Coaching moves — field by field

For each field: what a weak answer looks like, and the one question that tests it. Ask the test question once.
If the student still cannot answer, record the honest answer ("not documented", "not measured", "unknown")
and move on. Never argue a student into a different option; make them see the evidence and let them choose.

## Section 1 · The tool
| Field | Weak answer | Test question |
|---|---|---|
| 1b Workflow | "Improves collaboration", "digital transformation", "efficiency" | "Which piece of work, done by whom, starts and ends differently because of this tool? Say it as a verb and an object: *approve change requests*, *schedule maintenance crews*." |
| 1c Where it stands | Picks "In production" for a pilot | "Is it running the real work for the real users today, or a subset?" A pilot is "Bought, being implemented". |
| 1d AI? | "No" for a tool that scores, ranks, forecasts or generates | "Does any output depend on a model trained on data — a risk score, a priority, a forecast, a draft?" If the vendor says AI and nobody knows what it does: "Unsure" — and say that this is a finding. |

## Section 2 · VCAP triage
| Field | Weak answer | Test question |
|---|---|---|
| 2a Term | Claims C because "people learned the tool" | "Training to operate the system is part of delivering the asset. If the system were switched off tomorrow, what would the organisation still be better at?" |
| 2b C claim | Any answer that names the tool or depends on it | "Remove the tool from your sentence. Does the sentence still say something?" If not, ask whether they want to revisit 2a — and accept their answer. |
| 2c WIP | "Yes" because dashboards show WIP | "Showing work in progress is not limiting it. What stops the 21st item from starting when 20 are in flight?" |
| 2d One place | "The one place" while spreadsheets still exist | "Is the old source switched off? Who still keeps a copy, and who reconciles it?" |
| 2e Adoption | Login counts, licences, "everyone has access" | "Of the people meant to do their work inside it, how many actually do — and how do you know?" Record "unknown" if nobody knows; "too early" if not live. |
| 2f Parity | "Longer" because "we chose the best vendor" | "Could a rival with the same budget sign the same contract next quarter? What would they have to build that they cannot buy?" In regulated or public organisations with no direct competitor, read "competitor" as another operator or agency with the same budget. |

## Section 3 · The six conditions
Remind once: the useful answer is the **first condition that is not a clear yes**. Keep going after it — the
rest are still worth recording — but name it when you reach it.

| Field | Weak answer | Test question |
|---|---|---|
| 3.0 Evidence | A vendor case study, a pilot accuracy figure, an analyst report | "Did somebody independent measure a result in an organisation like yours after implementation — not a model, not a demo?" |
| 3.1 Technical | "The vendor reports 95% accuracy" | "Measured on whose data, at which cut-off? Has anyone checked it here, after go-live, counting only outputs that told people something new?" |
| 3.2 Integration | Names a dashboard or "the team" | "Name the role and the step. Does the output arrive *before* that person decides — or is it available if they go looking?" |
| 3.2b Who receives | "Everyone can see it" | "Available is not delivered. What is the evidence that it is opened and used at that step?" |
| 3.3 Action | "The manager will act on it" | "When the output says X, who does what, using what? Does acting need an approval, a budget or a resource nobody has?" |
| 3.4 Outcome | Satisfaction survey, "better visibility", NPS of users | "One indicator, one data source, one baseline. What number, from which system, compared with what starting value?" |
| 3.5 Net value | Only the hours saved | "Where did the saved work go? Who checks the output, who is de-prioritised, which hours moved to someone else?" |
| 3.6 Evidence quality | "None" (no weakness) for vendor-supplied figures | "Was there a comparison group at the same time? Is the measure objective? Is the source selling the tool?" Vendor material usually fails at least two. |

## Section 4 · Philosophical debt (AI only)
The question is never "is the system good?" It is "did anyone write the assumption down?"

| Field | Weak answer | Test question |
|---|---|---|
| 4.1 Optimising for | The business goal ("better decisions", "customer satisfaction") | "What number does the system itself try to push up or down? If nobody can say, write *unknown* — that is the finding." |
| 4.2 Hierarchy | "Yes" because there is a project charter | "When cost and service level conflict, where is it written which wins — and who owns that document?" |
| 4.3 Uncertainty | "It shows a confidence score" | "Does anything *happen* when confidence is low? Who is alerted, automatically?" |
| 4.4 Invalidation | "Nothing" / "it retrains itself" | "Name the event that would end the conditions its data came from: a market shift, a regulation, a reorganisation." For vendor-trained generative AI (a copilot, an LLM), ask instead: "Which of *your* conditions does it rely on — your templates, your historical records, your terminology — and what change on your side would make its outputs stale?" |
| 4.5 Stand-in | Names only the proxy | "Three things: what you care about, what the system was given instead, and one thing that matters to the decision that the measure cannot see." |
| 4.6 Review | "IT monitors it" | "Monitoring uptime is not reviewing representation. Who decides what the system is able to see, and when do they look again?" |

## Section 5 · The verdict
- **Ranking.** Ask the student to rank before you comment. Then test the top item: "If you paid only this debt
  and left the others, would the result arrive?" Common trap: ranking Technical first because the model
  failed, when the debt that made the failure fatal was Philosophical or Capability.
- **Decision.** It must follow from sections 2–4. "Proceed" with condition 2 or 3 at "No" is inconsistent: say
  so and ask them to reconcile — do not change it for them.
- **First step.** One line, a verb, an owner with a role name, and something observable. "Improve adoption" is
  not a step; "The PMO lead switches off the legacy tracker by 30 November" is.

## Patterns worth naming when they appear
- **Paying for A, booking C.** The business case's benefits assume the organisation will improve itself; the
  tool only adds an asset.
- **Not measured ≠ failed.** An unobserved implementation is more tractable than a failing one; the next step
  is to measure, not to spend.
- **Integration succeeded, so nothing stood in the way.** A perfectly integrated output with no human check can
  make a failure systematic (see the worked example only if the student asks for one).
- **One more copy.** A tool that becomes a second source of truth creates reconciliation work forever.
- **Relocated, not saved.** Hours saved in one place reappearing as overtime elsewhere.
